import os
import numpy as np
from torch.optim import Adam
from data_loader import *
from torch.utils.data import DataLoader
from HBay_model_pretrain import ManModel
from HetEmb import HetEmb
from utils import (extract_words_vocab, pad_sentence_batch,load_poi_time, load_poi_cat, positional_encoding,
                   calculate_acc, EarlyStopping)

from loss import (recon_loss, total_kld)

if not os.path.isdir('pretrains'):
    # 创建文件夹
    os.mkdir('pretrains')


def read_batch_history(user):
    # 处理历史数据，作为模型的输入
    his_traj = []
    his_time = []
    his_cat = []
    for uid in user:
        his_traj.append(history_traj[uid])
        his_time.append(history_time[uid])
        his_cat.append(history_cat[uid])
    his_traj = torch.tensor(pad_sentence_batch(his_traj, 0)).to(device)
    his_time = torch.tensor(pad_sentence_batch(his_time, 0)).to(device)
    his_cat = torch.tensor(pad_sentence_batch(his_cat, 0)).to(device)
    return his_traj, his_time, his_cat


batch_size = 64
emb_dim = 256
his_emb_dim = 256
hidden_dim = 512
z_dim = 128
time_num = 48 + 1
# cat_num = 183+1  # TKY
cat_num = 201 + 1  # NYC
# cat_num = 292  # HOU
# cat_num = 285  # LA

# dist = 'normal'
dist = 'vmf'
emb_method = 'node2vec'
# emb_method = 'random'

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
city = 'NYC'
train_file = 'data/' + city + '/' + city + '_traj_train.txt'
test_file = 'data/' + city + '/' + city + '_traj_test.txt'
time_train_file = 'data/' + city + '/' + city + '_traj_time_train.txt'
time_test_file = 'data/' + city + '/' + city + '_traj_time_test.txt'
cat_train_file = 'data/' + city + '/' + city + '_traj_cat_train.txt'
cat_test_file = 'data/' + city + '/' + city + '_traj_cat_test.txt'
poi_time_file = 'data/' + city + '/' + city + '_poi_time.txt'
poi_cat_file = 'data/' + city + '/' + city + '_poi_cat.txt'

# 数据预处理
train_traj, train_time, train_cat, test_traj, test_time, test_cat, \
    history_traj, history_time, history_cat, voc_poi, train_user, test_user = data_process(
        train_file, test_file, time_train_file, time_test_file, cat_train_file, cat_test_file
    )

int_to_vocab, vocab_to_int = extract_words_vocab(voc_poi)

poi_num = len(int_to_vocab) + 1
poi_time_list = load_poi_time(poi_time_file, int_to_vocab)
poi_cat_list = load_poi_cat(poi_cat_file, int_to_vocab)

# 导入预训练的嵌入层
node2vec_emb = torch.from_numpy(np.loadtxt('./embeddings/{}_node2vec_256.txt'.format(city))).to(torch.float32)
# contra_emb = torch.from_numpy(np.array(pd.read_csv('./embeddings/{}_contrastive_128.csv'.format(city)))).to(
#   torch.float32)
# data_emb = torch.cat([node2vec_emb, contra_emb], dim=1)
data_emb = node2vec_emb

# 对时间和类别计算嵌入层
zeros = torch.zeros([poi_num-1, 1])
hetEmb = HetEmb(ct_dim=emb_dim, time_num=time_num, cat_num=cat_num)
poi_time = torch.tensor(poi_time_list).float()
poi_cat = torch.tensor(poi_cat_list).float()
poi_time = torch.cat([zeros, poi_time], dim=1)
poi_cat = torch.cat([zeros, poi_cat], dim=1)
pt_emb, pc_emb, time_emb, cat_emb = hetEmb(poi_time, poi_cat)

total_data_set = MyDataset(data=train_traj, user=train_user, time=train_time, cat=train_cat,
                           del_label_flag=True, padding_idx=0, use_sos_eos=None)

data_iter = DataLoader(dataset=total_data_set, batch_size=batch_size, shuffle=True)


pos_encoding = positional_encoding(len(vocab_to_int), his_emb_dim).to(device)

model = ManModel(emb_dim=emb_dim, his_emb_dim=his_emb_dim, node_num=poi_num, hidden_dim=hidden_dim, z_dim=z_dim,
                 data_emb=data_emb, time_emb=time_emb, cat_emb=cat_emb, dist=dist).to(device)

# print(model)
optimizer = Adam(model.parameters(), lr=0.005, betas=(0.9, 0.99), eps=1e-08, weight_decay=0.00001, amsgrad=True)
stopper = EarlyStopping(
    patience=5000, model_name='./pretrains/{}_manifold_pretrain_checkpoint'.format(city) + '_' + str(emb_method) +
                              '___' + str(dist) + '.pt'
)


def train(model, optimizer, data_iters, pos_encoding, epochs=15):
    model_kwargs = {}
    model_kwargs.update({'pos_encoding': pos_encoding})
    loss_type = 'entropy'
    pad_id = 0
    for epoch in range(epochs):
        model.train()
        for step, (traj, user, time, cat, label, length, mask) in enumerate(data_iters):
            # 将数据放入GPU
            traj, time, cat, label, mask, = traj.to(device), time.to(device), cat.to(device), label.to(device), mask.to(
                device)
            B, L = traj.shape

            optimizer.zero_grad()
            inputs = traj
            targets = traj
            q_z, p_z, z, outputs = model(traj, time, cat, length, mask)
            if loss_type == 'entropy':
                reloss = recon_loss(outputs, targets, pad_id, id=loss_type)
            else:
                reloss = recon_loss(inputs, outputs, pad_id, id=loss_type)

            kld = total_kld(q_z, p_z, dist)
            loss = reloss + kld / B

            dec_mask = torch.broadcast_to(mask.unsqueeze(dim=-1), outputs.shape)
            out_pre = torch.masked_select(outputs, dec_mask).reshape(-1, outputs.size(-1))
            out_pre = torch.nn.functional.softmax(out_pre, dim=-1)
            predict_x = torch.argmax(out_pre, dim=-1)

            mask_data = torch.masked_select(traj, mask)
            acc = calculate_acc(predict_x.tolist(), mask_data.tolist()) / len(mask_data)
            # torch.autograd.set_detect_anomaly(True)
            loss.backward()  # retain_graph=True
            optimizer.step()

            if step % 100 == 0:
                print('\n{}'.format(predict_x.tolist()[:10]))
                print(mask_data.tolist()[:10])
                print('epoch: ', epoch + 1, '---batch: ', step, '---Loss:', loss.item(), '---acc', acc, '---kld',
                      kld / B)
            if stopper.step(acc, model):
                break


if __name__ == '__main__':
    train(model=model, optimizer=optimizer, data_iters=data_iter, pos_encoding=pos_encoding)
