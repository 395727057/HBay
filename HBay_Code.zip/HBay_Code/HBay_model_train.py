import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence as pack
from torch.nn.utils.rnn import pad_packed_sequence as unpack
import math
import copy
from torch.distributions.normal import Normal
from hyperspherical_vae.distributions.hyperspherical_uniform import HypersphericalUniform
from hyperspherical_vae.distributions.von_mises_fisher import VonMisesFisher


class LinearUnit(nn.Module):
    def __init__(self, in_features, out_features, batchnorm=True, nonlinearity=nn.LeakyReLU(0.2)):
        super(LinearUnit, self).__init__()
        if batchnorm is True:
            self.model = nn.Sequential(
                nn.Linear(in_features, out_features),
                nn.BatchNorm1d(out_features), nonlinearity)
        else:
            self.model = nn.Sequential(
                nn.Linear(in_features, out_features), nonlinearity)

    def forward(self, x):
        return self.model(x)


class ManModel(nn.Module):
    def __init__(self, emb_dim, node_num, hidden_dim, z_dim, data_emb, time_emb, cat_emb, dropout=0.5, dist='normal'):
        super(ManModel, self).__init__()
        self.emb_dim = emb_dim
        self.ct_dim = emb_dim
        self.his_e_dim = 128
        self.hidden_dim = hidden_dim
        self.z_dim = z_dim
        self.head = head = 4
        self.max_len_seq = 10
        self.dist = dist

        self.data_emb = nn.Embedding.from_pretrained(data_emb, padding_idx=0)
        self.time_emb = nn.Embedding.from_pretrained(time_emb, padding_idx=0)
        self.cat_emb = nn.Embedding.from_pretrained(cat_emb, padding_idx=0)
        # 使用随机embedding做对比实验
        # self.data_emb = nn.Embedding(node_num, emb_dim, padding_idx=0)
        # self.time_emb = nn.Embedding(49, self.ct_dim, padding_idx=0)
        # self.cat_emb = nn.Embedding(202, self.ct_dim, padding_idx=0)  # NYC
        # self.cat_emb = nn.Embedding(184, self.ct_dim, padding_idx=0)  # TKY
        # self.cat_emb = nn.Embedding(292, self.ct_dim, padding_idx=0)  # HOU
        # self.cat_emb = nn.Embedding(285, self.ct_dim, padding_idx=0)  # LA

        self.emb = nn.Linear(emb_dim + self.ct_dim * 2, emb_dim)  # poi+poi_time+poi_category
        self.his_emb = nn.Linear(emb_dim + self.ct_dim * 2, self.his_e_dim)  # poi+poi_time+poi_category

        # 位置信息嵌入
        self.position_embeddings = PositionalEncoding(
            d_model=emb_dim, dropout=dropout, max_len=self.max_len_seq
        )

        # ----------------------Encoder部分--------------------
        self.enc_bi = nn.GRU(emb_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.enc_uni = nn.GRU(hidden_dim * 2, hidden_dim, batch_first=True)

        # ----------------------重参数部分----------------------
        self.mean = LinearUnit(hidden_dim, z_dim, False)
        self.log_var = nn.Linear(hidden_dim, z_dim)
        self.log_var_man = nn.Linear(hidden_dim, 1)
        self.z_mlp = nn.Linear(z_dim, hidden_dim)
        # ----------------------Decoder部分----------------------
        self.traj_rnn = nn.GRU(emb_dim, hidden_dim, batch_first=True)
        self.cat_rnn = nn.GRU(emb_dim, hidden_dim, batch_first=True)

        # ---------------------历史轨迹处理-------------------------
        # 从历史轨迹中提取隐藏状态
        self.his_attn = MultiHeadedAddAttention(
            h=head, q_model=hidden_dim, k_model=self.his_e_dim, v_model=self.his_e_dim, d_model=hidden_dim,
            dropout=dropout, bias=True)

        # self.short_attn = MultiHeadedAddAttention(
        #     h=head, q_model=hidden_dim, k_model=emb_dim, v_model=emb_dim, d_model=hidden_dim//2,
        #     dropout=dropout, bias=True)

        # 激活函数以及其他
        self.out = nn.Linear(self.hidden_dim * 2, node_num)
        self.dropout = nn.Dropout(0.5)
        self.tanh = nn.Tanh()
        self.soft_plus = nn.Softplus()
        # loss
        self.loss = nn.CrossEntropyLoss(reduction='mean')

    def forward(self, x, label, time, cat, length, mask, pos_encoding, **model_kwargs):
        assert model_kwargs is not None
        # poi-time-cat embedding concat
        embedded, traj_embs, cat_embs = self.get_embedding(x, time, cat)
        emb_data = self.emb(embedded)
        # emb_data = embedded
        history_traj = model_kwargs.pop('his_traj')
        history_time = model_kwargs.pop('his_time')
        history_cat = model_kwargs.pop('his_cat')
        his_L = history_traj.size(1)

        his_embed, his_traj_embs, his_cat_embs = self.get_embedding(history_traj, history_time, history_cat)
        his_embed = self.dropout(self.his_emb(his_embed))
        # 历史轨迹位置嵌入和掩码矩阵
        his_embed += pos_encoding[:, :his_L, :]
        his_mask = history_traj.gt(0)

        # ------------------VAE部分-------------------
        # rnn作为encoder
        # enc_output, enc_hidden = self.encoder(emb_data, length)
        enc_hidden = self.encoder(emb_data, length)
        # q_z, p_z = self.reparameterization(enc_hidden.squeeze(0), dist=self.dist)
        # if self.training:
        #     z = q_z.rsample()
        # else:
        #     z = q_z.mean
        # init_hidden = torch.tanh(self.z_mlp(z)).unsqueeze(0)
        init_hidden = enc_hidden
        # cat_out, cat_hidden = self.decoder(emb_data, length, dec_rnn=self.cat_rnn, init_hidden=init_hidden)
        outputs, hidden = self.decoder(emb_data, length, dec_rnn=self.traj_rnn, init_hidden=init_hidden)

        dec_hidden = hidden[-1].unsqueeze(0).transpose(0, 1)  # dec为RNN时
        dec_hidden = self.soft_plus(dec_hidden)
        # ---------------从历史轨迹中提取信息-----------------
        his_hidden = self.get_his_attn(dec_hidden, his_embed, his_mask)
        output_hidden = torch.cat([dec_hidden, his_hidden], dim=-1).squeeze(1)

        predict_x = self.out(output_hidden)
        loss = self.loss(predict_x, label)
        predict_x = F.softmax(predict_x, dim=-1)
        return predict_x, loss

    def get_embedding(self, data, time, cat):
        traj_embs = self.data_emb(data)
        time_embs = self.time_emb(time)
        cat_embs = self.cat_emb(cat)
        embedded = torch.cat((traj_embs, time_embs, cat_embs), dim=2)
        return embedded, traj_embs, cat_embs

    def encoder(self, x, lengths):
        B, L = x.shape[0], x.shape[1]
        pack = nn.utils.rnn.pack_padded_sequence(x, lengths.cpu(), batch_first=True, enforce_sorted=False)
        out_bi, hidden_bi = self.enc_bi(pack)
        out_bi, _ = nn.utils.rnn.pad_packed_sequence(out_bi, batch_first=True, total_length=L)

        out_bi = self.dropout(out_bi)

        pack_bi = nn.utils.rnn.pack_padded_sequence(out_bi, lengths.cpu(), batch_first=True, enforce_sorted=False)
        out_uni, hidden_uni = self.enc_uni(pack_bi)
        out_uni, _ = nn.utils.rnn.pad_packed_sequence(out_uni, batch_first=True, total_length=L)

        hidden_uni = hidden_uni.squeeze(1)

        return hidden_uni

    def reparameterization(self, hidden, dist='normal'):
        B = hidden.size(0)
        if dist == 'normal':
            p_z = Normal(torch.zeros((B, self.z_dim), device=hidden.device),
                         (0.5 * torch.zeros((B, self.z_dim), device=hidden.device)).exp())
            mu = self.mean(hidden)
            lv = F.softplus(self.log_var(hidden))
            return Normal(mu, (0.5 * lv).exp()), p_z

        elif dist == 'vmf':
            mu = self.mean(hidden)
            mu = mu / mu.norm(dim=-1, keepdim=True)
            var = F.softplus(self.log_var_man(hidden))
            # noise = torch.randn_like(var)
            kappa = (0.5 * var).exp() * self.scaled
            return VonMisesFisher(mu, kappa), HypersphericalUniform(mu.size(0), self.z_dim - 1, device=mu.device)
        else:
            raise NotImplementedError

    def decoder(self, inputs, lengths, dec_rnn, init_hidden):
        L = inputs.size(1)
        inputs = self.dropout(inputs)
        if lengths is not None:
            inputs = pack(inputs, lengths, batch_first=True, enforce_sorted=False)
        if init_hidden is not None:
            outputs, hidden = dec_rnn(inputs, init_hidden)
        else:
            outputs, hidden = dec_rnn(inputs)
        if lengths is not None:
            outputs, _ = unpack(outputs, batch_first=True, total_length=L)
        outputs = self.dropout(outputs)
        return outputs, hidden

    def get_his_attn(self, query, his_h, his_mask):
        # his_user_attn = self.his_self_attn(his_h)*his_mask.unsqueeze(-1)
        his_h *= math.sqrt(his_h.size(-1))

        return self.dropout(self.his_attn(query, his_h, his_h, his_mask))

class MultiHeadedAddAttention(nn.Module):
    def __init__(self, h, q_model, k_model, v_model, d_model, dropout=0.1, bias=False):
        super(MultiHeadedAddAttention, self).__init__()
        assert d_model % h == 0
        self.d_k = d_model // h
        self.h = h
        self.W_q = nn.Linear(q_model, d_model, bias=bias)
        self.W_k = nn.Linear(k_model, d_model, bias=bias)
        self.W_v = nn.Linear(v_model, d_model, bias=bias)
        self.W_o = nn.Linear(d_model, d_model, bias=bias)

        self.W_a = nn.Linear(d_model // h, 1, bias=bias)
        self.attn = None
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, query, key, value, mask=None):
        if mask is not None:
            # Same mask applied to all h heads.
            mask = mask.unsqueeze(1)
        B = query.size(0)

        # 1) Do all the linear projections in batch from d_model => h x d_k
        query, key, value = [l(x).view(B, -1, self.h, self.d_k).transpose(1, 2) for l, x in
                             zip((self.W_q, self.W_k, self.W_v), (query, key, value))]

        # 2) Apply attention on all the projected vectors in batch.
        x, self.attn = self.add_attention(query, key, value, self.W_a, mask=mask, dropout=self.dropout)

        # 3) "Concat" using a view and apply a final linear.
        x = x.transpose(1, 2).contiguous().view(B, -1, self.h * self.d_k)  # contiguous()使得view不会改变数据顺序
        return self.W_o(x)

    def add_attention(self, query, key, value, w_a, mask=None, dropout=None):
        features = torch.tanh(query.unsqueeze(3) + key.unsqueeze(2))
        scores = w_a(features).squeeze(-1)
        if mask is not None:
            mask = torch.broadcast_to(mask.unsqueeze(2), scores.shape)
            scores = scores.masked_fill(mask == 0, -1e-9)
        weights = F.softmax(scores, dim=-1)
        if dropout is not None:
            weights = dropout(weights)
        return torch.matmul(weights, value), weights


class MultiHeadedAttention(nn.Module):
    def __init__(self, h, in_model, d_model, dropout=0.1):
        super(MultiHeadedAttention, self).__init__()
        assert d_model % h == 0
        self.d_k = d_model // h
        self.h = h
        self.linears = clones(nn.Linear(in_model, d_model), 3)
        self.out = nn.Linear(d_model, d_model)
        self.attn = None
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, query, key, value, mask=None):
        if mask is not None:
            # Same mask applied to all h heads.
            mask = mask.unsqueeze(1)
        B = query.size(0)

        # 1) Do all the linear projections in batch from d_model => h x d_k
        query, key, value = [l(x).view(B, -1, self.h, self.d_k).transpose(1, 2) for l, x in
                             zip(self.linears, (query, key, value))]
        # 2) Apply attention on all the projected vectors in batch.
        x, self.attn = self.attention(query, key, value, mask=mask, dropout=self.dropout)

        # 3) "Concat" using a view and apply a final linear.
        x = x.transpose(1, 2).contiguous().view(B, -1, self.h * self.d_k)
        return self.out(x)

    def attention(self, query, key, value, mask=None, dropout=None):
        d_k = torch.tensor(query.size(-1))
        scores = torch.matmul(query, key.transpose(-2, -1)) / torch.sqrt(d_k)  # 注意力计算公式
        if mask is not None:
            mask = torch.broadcast_to(mask.unsqueeze(-1), scores.shape)
            scores = scores.masked_fill(mask == 0, -1e-9)
        # 对维度进行归一化
        p_attn = F.softmax(scores, dim=-1)
        if dropout is not None:
            p_attn = dropout(p_attn)
        return torch.matmul(p_attn, value), p_attn


def clones(module, N):
    return nn.ModuleList([copy.deepcopy(module) for _ in range(N)])


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout, max_len=5000):
        """
        :param d_model: pe编码维度，一般与word embedding相同，方便相加
        :param dropout: dorp out
        :param max_len: 语料库中最长句子的长度，即word embedding中的L
        """
        super(PositionalEncoding, self).__init__()
        # 定义drop out
        self.dropout = nn.Dropout(p=dropout)
        # 计算pe编码
        pe = torch.zeros(max_len, d_model)  # 建立空表，每行代表一个词的位置，每列代表一个编码位
        position = torch.arange(0, max_len).unsqueeze(1)
        # 建个arrange表示词的位置以便公式计算，size=(max_len,1)
        i_mat = torch.pow(10000, torch.arange(0, d_model, 2).reshape(1, -1) / d_model)
        # div_term = torch.exp(torch.arange(0, d_model, 2) *  # 计算公式中10000**（2i/d_model)
        #                      -(math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position / i_mat)  # 计算偶数维度的pe值
        pe[:, 1::2] = torch.cos(position / i_mat)  # 计算奇数维度的pe值
        pe = pe.unsqueeze(0)  # size=(1, L, d_model)，为了后续与word_embedding相加
        self.register_buffer('pe', pe)  # pe值是不参加训练的

    def forward(self, x):
        # 输入的最终编码 = word_embedding + positional_embedding
        x = x + torch.tensor(self.pe[:, :x.size(1)], requires_grad=False)  # size = [batch, L, d_model]
        return self.dropout(x)  # size = [batch, L, d_model]
