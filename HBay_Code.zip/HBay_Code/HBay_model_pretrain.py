import torch
import torch.nn as nn
from torch.nn.utils.rnn import pack_padded_sequence as pack
from torch.nn.utils.rnn import pad_packed_sequence as unpack
import torch.nn.functional as F
from torch.distributions.normal import Normal
from torch_geometric.nn import GCNConv, SAGEConv, GATConv

from hyperspherical_vae.distributions.hyperspherical_uniform import HypersphericalUniform
from hyperspherical_vae.distributions.von_mises_fisher import VonMisesFisher


class LinearUnit(nn.Module):
    def __init__(self, in_features, out_features, batch_norm=True, non_linearity=nn.LeakyReLU(0.2)):
        super(LinearUnit, self).__init__()
        if batch_norm is True:
            self.model = nn.Sequential(
                nn.Linear(in_features, out_features),
                # nn.BatchNorm1d(out_features), non_linearity)
                nn.LayerNorm(out_features),
            )
        else:
            self.model = nn.Sequential(
                nn.Linear(in_features, out_features), non_linearity)

    def forward(self, x):
        return self.model(x)


class ManModel(nn.Module):
    def __init__(self, emb_dim, node_num, his_emb_dim, hidden_dim, z_dim, data_emb, time_emb, cat_emb, dist):
        super().__init__()
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.emb_dim = emb_dim
        self.ct_dim = emb_dim
        self.his_e_dim = his_emb_dim  # pos_encoding
        self.hidden_dim = hidden_dim
        self.z_dim = z_dim

        self.dist = dist
        self.scaled = 16

        # 嵌入层
        self.data_emb = nn.Embedding.from_pretrained(data_emb, padding_idx=0)
        self.time_emb = nn.Embedding.from_pretrained(time_emb, padding_idx=0)
        self.cat_emb = nn.Embedding.from_pretrained(cat_emb, padding_idx=0)
        # self.data_emb = nn.Embedding(node_num, emb_dim, padding_idx=0)
        # self.time_emb = nn.Embedding(49, self.ct_dim, padding_idx=0)
        # self.cat_emb = nn.Embedding(184, self.ct_dim, padding_idx=0)  # TKY
        # self.cat_emb = nn.Embedding(202, self.ct_dim, padding_idx=0)  # NYC
        # self.cat_emb = nn.Embedding(285, self.ct_dim, padding_idx=0)  # LA
        # self.cat_emb = nn.Embedding(292, self.ct_dim, padding_idx=0)  # HOU

        self.emb = nn.Linear(emb_dim + self.ct_dim * 2, emb_dim)  # poi+poi_time+poi_category

        # --------------------------Encoder部分-------------------------
        # RNN用于encoder
        self.enc_bi = nn.GRU(emb_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.enc_uni = nn.GRU(hidden_dim * 2, hidden_dim, batch_first=True)

        # ---------------------------重参数化--------------------------------
        self.mean = LinearUnit(hidden_dim, z_dim, False)
        self.log_var = nn.Linear(hidden_dim, z_dim)
        self.log_var_man = nn.Linear(hidden_dim, 1)
        self.z_mlp = nn.Linear(z_dim, hidden_dim)

        # --------------------------Decoder部分-------------------------------
        # dec使用rnn
        self.traj_rnn = nn.GRU(emb_dim, hidden_dim, batch_first=True)
        self.cat_rnn = nn.GRU(emb_dim, hidden_dim, batch_first=True)

        # VAE输出重构数据
        self.vae_out = nn.Linear(hidden_dim, node_num)

        # 损失函数与激活函数
        self.dropout = nn.Dropout(0.5)
        self.norm = nn.LayerNorm(hidden_dim // 4)
        self.tanh = nn.Tanh()
        self.loss = nn.CrossEntropyLoss(reduction='mean')

    def forward(self, traj, time, cat, lengths, mask):

        # poi-time-cat embedding concat
        embedded, traj_embs, cat_embs = self.get_embedding(traj, time, cat)
        emb_data = self.emb(embedded)

        # -----------------encoder部分------------------
        hidden, q_z, p_z = self.encoder(emb_data, lengths, dist=self.dist)

        if self.training:
            z = q_z.rsample()
        else:
            z = q_z.mean

        init_hidden = torch.tanh(self.z_mlp(z))
        outputs, hidden = self.decoder(emb_data, lengths, dec_rnn=self.traj_rnn, init_hidden=init_hidden)

        outputs = self.vae_out(outputs)

        return q_z, p_z, z, outputs

    def get_embedding(self, data, time, cat):
        time_embs = self.time_emb(time)
        traj_embs = self.data_emb(data)
        cat_embs = self.cat_emb(cat)
        embedded = torch.cat((traj_embs, time_embs, cat_embs), dim=2)
        return embedded, traj_embs, cat_embs


    def encoder(self, x, lengths, dist='normal'):
        B, L = x.shape[0], x.shape[1]
        pack_input = pack(x, lengths.cpu(), batch_first=True, enforce_sorted=False)
        out_bi, hidden_bi = self.enc_bi(pack_input)
        out_bi, _ = unpack(out_bi, batch_first=True, total_length=L)

        out_bi = self.dropout(out_bi)

        pack_bi = pack(out_bi, lengths.cpu(), batch_first=True, enforce_sorted=False)
        out_uni, hidden_uni = self.enc_uni(pack_bi)
        out_uni, _ = unpack(out_uni, batch_first=True, total_length=L)

        hidden = hidden_uni.squeeze(1)
        # --------------重参数化--------------
        if dist == 'normal':
            p_z = Normal(torch.zeros((B, self.z_dim), device=hidden.device),
                         (0.5 * torch.zeros((B, self.z_dim), device=hidden.device)).exp())
            mu = self.mean(hidden)
            lv = F.softplus(self.log_var(hidden))
            return hidden, Normal(mu, (0.5 * lv).exp()), p_z

        elif dist == 'vmf':
            mu = self.mean(hidden)
            mu = mu / mu.norm(dim=-1, keepdim=True)
            var = F.softplus(self.log_var_man(hidden))
            # noise = torch.randn_like(var)
            kappa = (0.5 * var).exp() * self.scaled
            return hidden, VonMisesFisher(mu, kappa), HypersphericalUniform(mu.size(0), self.z_dim - 1,
                                                                            device=mu.device)
        else:
            raise NotImplementedError

    def decoder(self, inputs, lengths, dec_rnn, init_hidden=None):
        L = inputs.size(1)
        inputs = self.dropout(inputs)
        if lengths is not None:
            inputs = pack(inputs, lengths, batch_first=True, enforce_sorted=False)
        if init_hidden is not None:
            outputs, hidden = dec_rnn(inputs, init_hidden)
        else:
            outputs, hidden = dec_rnn(inputs)
        if lengths is not None:
            outputs, _ = unpack(outputs, batch_first=True, total_length=L)
        outputs = self.dropout(outputs)
        return outputs, hidden
