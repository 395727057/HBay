import numpy as np
import torch
import pandas as pd
from torch.utils.data import TensorDataset
from utils import build_dictionary, read_data, flatten, extract_words_vocab


def data_process(traj_train, traj_test, time_train, time_test, cat_train, cat_test):
    voc_poi = []
    # poi词典
    voc_poi = build_dictionary(traj_train, traj_test, voc_poi)
    # 读取poi、time和cat的值
    Train_DATA, Train_USER, Test_DATA, Test_USER = read_data(traj_train, traj_test)
    Train_TIME, _, Test_TIME, _ = read_data(time_train, time_test)
    Train_CAT, _, Test_CAT, _ = read_data(cat_train, cat_test)

    int_to_vocab, vocab_to_int = extract_words_vocab(voc_poi)

    train_traj = convert_data(Train_DATA, vocab_to_int)
    test_traj = convert_data(Test_DATA, vocab_to_int)
    train_time = convert_het_data(Train_TIME)
    test_time = convert_het_data(Test_TIME)
    train_cat = convert_het_data(Train_CAT)
    test_cat = convert_het_data(Test_CAT)

    # train_traj, train_time, train_cat = time_sort(train_traj, train_time, train_cat)
    his_traj, his_time, his_cat = his_data_gen(train_traj, train_time, train_cat, Train_USER)

    # test_traj, test_time, test_cat = time_sort(test_traj, test_time, test_cat)

    his_traj = read_history_data(his_traj)
    his_time = read_history_data(his_time)
    his_cat = read_history_data(his_cat)

    T = train_traj + test_traj
    # 统计全部的POI数和用户数
    total_check = len(flatten(T))
    total_user = set(flatten(Train_USER + Test_USER))
    user_number = len(set(total_user))

    print(len(int_to_vocab))
    print('Dictionary Length', len(int_to_vocab), 'POI number', len(int_to_vocab) - 3)
    TOTAL_POI = len(int_to_vocab)
    print('Total check-ins', total_check, TOTAL_POI)
    print('Total Users', user_number)

    return train_traj, train_time, train_cat, test_traj, test_time, test_cat, his_traj, his_time, his_cat, voc_poi,\
        Train_USER, Test_USER


def read_history_data(data):
    History = {}
    for key in data.keys():  # index char
        temp = data[key]
        History[key] = flatten(temp)
    return History


def his_data_gen(traj, time, cat, user):
    his_traj = {}
    his_time = {}
    his_cat = {}
    for i in range(len(traj)):
        his_traj.setdefault(user[i], []).append(traj[i])
        his_time.setdefault(user[i], []).append(time[i])
        his_cat.setdefault(user[i], []).append(cat[i])
    return his_traj, his_time, his_cat


def time_sort(traj, time, cat):
    # 对数据按照时间进行排序
    index_list = []
    for i in range(len(time)):
        index = np.argsort(time[i])
        traj[i] = traj[i][index].tolist()
        time[i] = time[i][index].tolist()
        cat[i] = cat[i][index].tolist()
        index_list.append(index)
    return traj, time, cat


def convert_data(DATA, vocab_to_int):
    new_DATA = list()
    for i in range(len(DATA)):  # TRAIN
        temp = list()
        for j in range(len(DATA[i])):
            temp.append(vocab_to_int[DATA[i][j]])
        # temp = np.array(temp)
        new_DATA.append(temp)
    return new_DATA


def convert_het_data(DATA):
    new_DATA = list()
    for i in range(len(DATA)):  # TRAIN
        temp = list()
        for j in range(len(DATA[i])):
            temp.append(int(DATA[i][j]) + 1)
        # temp = np.array(temp)
        new_DATA.append(temp)
    return new_DATA


# 定义自己的Dataset类
class MyDataset(TensorDataset):
    def __init__(self, data, user, time, cat, padding_idx, use_sos_eos, del_label_flag=False):
        super(TensorDataset, self).__init__()
        # 读取数据文件
        self.data = data
        self.user = user
        self.time = time
        self.cat = cat

        self.label_flag = del_label_flag
        self.padding_idx = padding_idx
        self.sos_eos = use_sos_eos

        # 获取数据的标签
        label = self.get_label(data)
        if self.label_flag:
            # 删除数据的标签
            data = self.del_label(data)
            time = self.del_label(time)
            cat = self.del_label(cat)

        # 填充数据与起止符设置
        max_poiid = max(max(row) for row in data)
        sos = [max_poiid + 1]
        eos = [max_poiid + 2]
        pad = self.padding_idx
        # 对数据进行填充

        data, lengths_list = self.pad_sentence_batch(data, pad)
        time_list, _ = self.pad_sentence_batch(time, pad)
        cat_list, _ = self.pad_sentence_batch(cat, pad)

        self.poi_num = max_poiid + 1
        # 数据添加起止符
        if self.sos_eos:
            data = self.add_sos_eos(data, sos, eos)
            self.poi_num = self.poi_num + 2

        # 将数据进行转换
        self.data = torch.tensor(data)
        self.time = torch.tensor(time_list)
        self.cat = torch.tensor(cat_list)
        self.label = torch.tensor(label)
        self.lengths = torch.tensor(lengths_list)

        # a = Counter(self.label)
        # 设定掩码矩阵
        mask = self.data.cpu().detach().gt(0)
        self.mask = mask

    def __len__(self):
        # 返回数据集的大小
        return len(self.data)

    def __getitem__(self, index):
        return \
            self.data[index], self.user[index], self.time[index], self.cat[index], self.label[index], self.lengths[index], self.mask[index]

    def get_poi_num(self):
        return self.poi_num

    def pad_sentence_batch(self, sentence_batch, pad_idx):
        max_sentence = max([len(sentence) for sentence in sentence_batch])  # 取最大长度
        lengths_list = [len(sentence) for sentence in sentence_batch]
        return [sentence + [pad_idx] * (max_sentence - len(sentence)) for sentence in sentence_batch], lengths_list

    def add_sos_eos(self, trajectoreis, sos, eos):
        # 添加开始符号和终止符号
        for i in range(len(trajectoreis)):
            trajectoreis[i] = sos + trajectoreis[i] + eos
        return trajectoreis

    def get_label(self, trajectoreis):
        label = []
        for i in range(len(trajectoreis)):
            label.append(trajectoreis[i][-1])
        return label

    def del_label(self, trajectoreis):  # 去掉轨迹的最后一个poi
        nolabel_trajectorties = []
        for trajectory in trajectoreis:
            nolabel_trajectorties.append(trajectory[:-1])
        return nolabel_trajectorties
