import torch
import pandas as pd
import numpy as np
import os.path as osp
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from build_Graph1 import BuildGraph
from torch_geometric.nn import Node2Vec
from torch_geometric.datasets import Planetoid

emb_dim = 256

# dataset = 'Cora'
# path = osp.join(osp.dirname(osp.realpath(__file__)), '..', 'data', dataset)
# dataset = Planetoid(path, dataset)
# data = dataset[0]
# print(data.edge_index)

city = 'LA'
train_file = "data/{}/{}_traj_train.txt".format(city, city)
test_file = "data/{}/{}_traj_test.txt".format(city, city)
G = BuildGraph('../', 'train').process(train_file, test_file)
device = 'cuda' if torch.cuda.is_available() else 'cpu'
poi_num = G.num_nodes+1
model = Node2Vec(G.edge_index, embedding_dim=emb_dim, walk_length=10, context_size=10, walks_per_node=20, num_nodes=poi_num,
                 num_negative_samples=10, sparse=True).to(device)
model.embedding = torch.nn.Embedding(poi_num, emb_dim, padding_idx=0, sparse=True).cuda()

loader = model.loader(batch_size=64, shuffle=True, num_workers=4)
optimizer = torch.optim.SparseAdam(model.parameters(), lr=0.01)


def train():
    model.train()
    total_loss = 0
    # optimizer.zero_grad()
    # loss = model.loss(G.edge_index, edge_weight=G.edge_attr)
    # loss.backward()
    # optimizer.step()
    # return loss.item()
    for pos_rw, neg_rw in loader:
        optimizer.zero_grad()
        loss = model.loss(pos_rw.to(device), neg_rw.to(device))
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(loader)


# @torch.no_grad()
# def test():
#     model.eval()
#     z = model()
#     acc = model.test(z[data.train_mask], data.y[data.train_mask],
#                      z[data.test_mask], data.y[data.test_mask], max_iter=150)
#     return acc


for epoch in range(1, 50):
    loss = train()
    # acc = test()
    print(f'Epoch: {epoch:02d}, Loss: {loss:.4f}')


weight = torch.tensor(model.embedding.weight).cpu().numpy()
np.savetxt('./embeddings/{}_node2vec_{}.txt'.format(city, emb_dim), weight)
print('finish')


# @torch.no_grad()
# def plot_points(colors):
#     model.eval()
#     z = model(torch.arange(G.x, device=device))
#     z = TSNE(n_components=2).fit_transform(z.cpu().numpy())
#     y = data.y.cpu().numpy()
#
#     plt.figure(figsize=(8, 8))
#     for i in range(G.x):
#         plt.scatter(z[y == i, 0], z[y == i, 1], s=20, color=colors[i])
#     plt.axis('off')
#     plt.show()

#
# colors = ['#ffc0cb', '#bada55', '#008080', '#420420', '#7fe5f0', '#065535', '#ffd700']
# plot_points(colors)
