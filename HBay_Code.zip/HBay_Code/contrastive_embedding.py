import pandas as pd
import numpy as np
import tensorflow as tf
import pickle
from tensorflow.keras import Model
from tensorflow.keras.layers import Dot, Embedding, Flatten
import time
import os
os.getcwd()

# os.environ["CUDA_VISIBLE_DEVICES"]="-1"


def build_dictionary(data):
    voc_poi = []
    for list in data:
        for poi in list:
            if poi not in voc_poi:
                voc_poi.append(poi)
    return voc_poi


def extract_words_vocab(voc_poi):
    int_to_vocab = {idx + 1: word for idx, word in enumerate(voc_poi)}
    vocab_to_int = {word: idx for idx, word in int_to_vocab.items()}
    return int_to_vocab, vocab_to_int


def convert_data(DATA, vocab_to_int):
    new_DATA = list()
    for i in range(len(DATA)):  # TRAIN
        temp = list()
        for j in range(len(DATA[i])):
            temp.append(vocab_to_int[DATA[i][j]])
        new_DATA.append(temp)
    return new_DATA


def read_trajectories(train_file, test_file):
    trajectories = []
    with open(train_file, 'r') as f:
        lines = f.readlines()
        for line in lines:
            trajectories.append(line.strip().split('\t')[1:])
    with open(test_file, 'r') as f:
        lines = f.readlines()
        for line in lines:
            trajectories.append(line.strip().split('\t')[1:])
    return trajectories


def pad_sentence_batch(sentence_batch, pad_idx):
    max_sentence = max([len(sentence) for sentence in sentence_batch])  # 取最大长度
    lengths_list = [len(sentence) for sentence in sentence_batch]
    return [sentence + [pad_idx] * (max_sentence - len(sentence)) for sentence in sentence_batch], lengths_list


def read_rand_tra(rand_path):
    with open(rand_path, 'rb') as f:
        trajectories = pickle.load(f)
    return trajectories


class Word2Vec(Model):
    def __init__(self, vocab_size, embedding_dim, num_ns=3):
        super(Word2Vec, self).__init__()
        self.query_embedding = Embedding(vocab_size,
                                         embedding_dim,
                                         input_length=1,
                                         name="query_em_layer")
        self.poi_embedding = Embedding(vocab_size,
                                       embedding_dim,
                                       input_length=num_ns + 1,
                                       name='poi_em_layer')
        self.dots = Dot(axes=(3, 1))
        self.flatten = Flatten()

    def call(self, pair, **kwargs):
        target, context = pair
        word_emb0 = self.query_embedding(target[:, 0])
        word_emb1 = self.query_embedding(target[:, 1])
        word_emb = (word_emb0 + word_emb1) / 2
        context_emb = self.poi_embedding(context)
        dots = self.dots([context_emb, word_emb])

        return self.flatten(dots)


class PoiEmbedding( ):

    def __init__(self, trajectories, poi_num, num_ns=3):
        self.poi_num = poi_num
        self.trajectories = trajectories
        self.num_ns = num_ns
        self.positive_data = []
        self.dataset = None

    def gen_train(self):
        for trajectory in trajectories:
            true = set()
            for poi in trajectory:
                true.add(poi)
            for i in range(1, len(trajectory) - 1):
                target = (trajectory[i - 1], trajectory[i + 1])
                self.positive_data.append((target, trajectory[i], list(true)))

        print('正样本：', len(self.positive_data))

        targets, contexts, labels = [], [], []
        for target_pois, context_poi, true_class in self.positive_data:
            context_class = tf.constant(np.array([true_class]), dtype=tf.int64)
            negative_sampling_candidates, _, _ = tf.random.log_uniform_candidate_sampler(
                true_classes=context_class,
                num_true=len(true_class),
                num_sampled=self.num_ns,  # 正负样本的比例是1:self.num_ns
                unique=True,
                range_max=self.poi_num,
                seed=40,
                name="nagetive_sampling")

            # Build context and label vectors (for one target word)
            negative_sampling_candidates = tf.expand_dims(
                negative_sampling_candidates, 1)
            context_poi = tf.reshape(context_poi, [1, 1])
            context_poi = tf.cast(context_poi, dtype=tf.int64)
            context = tf.concat([context_poi, negative_sampling_candidates], 0)
            label = tf.constant([1] + [0] * self.num_ns, dtype="int64")

            # Append each element from the training example to global lists.
            targets.append(target_pois)  # 每个poi点的前后点  target tuple(poi[i-1], poi[i+1])
            contexts.append(context)  # 1个正样本+num_ns个负样本   context Tensor shape(1+num_ns,1)
            labels.append(label)  # context的label 1DTensor  shape(1+num_ns,)
        print(len(targets), len(contexts), len(labels))

        BATCH_SIZE = 128
        BUFFER_SIZE = 10000
        self.dataset = tf.data.Dataset.from_tensor_slices(((targets, contexts), labels))
        self.dataset = self.dataset.shuffle(BUFFER_SIZE).batch(BATCH_SIZE, drop_remainder=True)

    def train(self, em_size, name):
        embedding_dim = em_size  # poi嵌入维度
        word2vec = Word2Vec(self.poi_num, embedding_dim, self.num_ns)
        word2vec.compile(optimizer=tf.keras.optimizers.Adam(lr=0.0012),
                         loss=tf.keras.losses.CategoricalCrossentropy(from_logits=True),
                         metrics=['accuracy'])

        tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir="logs")
        word2vec.fit(self.dataset, epochs=60, callbacks=[tensorboard_callback])

        que_weights = word2vec.get_layer('query_em_layer').get_weights()[0]
        poi_weights = word2vec.get_layer('poi_em_layer').get_weights()[0]
        que_weights = pd.DataFrame(que_weights)
        print(que_weights.shape)
        poi_weights = pd.DataFrame(poi_weights)
        print(poi_weights.shape)
        # que_weights.to_csv('./self-embedding/'+city+'_que_weight.csv', index=False)
        # poi_weights.to_csv('./self-embedding/'+city+'_poi_weight.csv', index=False)
        poi_weights.to_csv('./embeddings/{}_contrastive_128.csv'.format(city), index=False)


if __name__ == '__main__':
    embbed_dim = 128
    city = 'TKY'
    train_file = "data/{}/{}_traj_train.txt".format(city, city)
    test_file = "data/{}/{}_traj_test.txt".format(city, city)

    trajectories = read_trajectories(train_file, test_file)

    voc_poi = build_dictionary(trajectories)
    int_to_vocab, vocab_to_int = extract_words_vocab(voc_poi)
    trajectories = convert_data(trajectories, vocab_to_int)

    tra = trajectories

    max_poiid = max(max(row) for row in tra)
    poi_num = max_poiid+1
    # sos = [max_poiid + 1]
    # eos = [max_poiid + 2]
    # pad = 0
    #
    # # 开始符号和终止符号
    # trajectories, lengths_list = pad_sentence_batch(tra, pad)

    start_time = time.time()
    self_embedding = PoiEmbedding(trajectories, poi_num, num_ns=256)
    self_embedding.gen_train()
    name = f'_{embbed_dim}_node'
    self_embedding.train(embbed_dim, name)
    print(time.time() - start_time)

# Max_node_id = max(max(i) for i in trajectories)
# print(Max_node_id)
print(len(trajectories))
