import os
import torch.nn as nn
from data_loader import *
from torch.utils.data import DataLoader
from HBay_model_train import ManModel
from tqdm import tqdm
import sklearn.metrics as metric
from HetEmb import HetEmb
from utils import extract_words_vocab, pad_sentence_batch, \
    load_poi_time, load_poi_cat, positional_encoding, EarlyStopping


os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

if not os.path.isdir('trains'):
    os.mkdir('trains')


def get_onehot(index):
    x = [0] * poi_num
    x[index] = 1
    return x


def read_batch_history(user):
    # 处理历史数据，作为模型的输入
    his_traj = []
    his_time = []
    his_cat = []
    for uid in user:
        his_traj.append(history_traj[uid])
        his_time.append(history_time[uid])
        his_cat.append(history_cat[uid])
    his_traj = torch.tensor(pad_sentence_batch(his_traj, 0)).to(device)
    his_time = torch.tensor(pad_sentence_batch(his_time, 0)).to(device)
    his_cat = torch.tensor(pad_sentence_batch(his_cat, 0)).to(device)
    return his_traj, his_time, his_cat


def weight_init(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_normal_(m.weight)
        nn.init.constant_(m.bias, 0)


batch_size = 128
emb_dim = 256
hidden_dim = 512
z_dim = 128
time_num = 48 + 1
cat_num = 201 + 1  # NYC
# cat_num = 183+1  # TKY
# cat_num = 291+1  # HOU
# cat_num = 284+1  # LA
lr = 0.0005

# dist = 'normal'
dist = 'vmf'

# pre_train = 'None'
pre_train = 'VAE'

emb_method = 'node2vec'
# emb_method = 'random'
device = 'cuda' if torch.cuda.is_available() else 'cpu'

# 读取不同城市的原始数据
city = 'NYC'
train_file = 'data/' + city + '/' + city + '_traj_train.txt'
test_file = 'data/' + city + '/' + city + '_traj_test.txt'
time_train_file = 'data/' + city + '/' + city + '_traj_time_train.txt'
time_test_file = 'data/' + city + '/' + city + '_traj_time_test.txt'
cat_train_file = 'data/' + city + '/' + city + '_traj_cat_train.txt'
cat_test_file = 'data/' + city + '/' + city + '_traj_cat_test.txt'
poi_time_file = 'data/' + city + '/' + city + '_poi_time.txt'
poi_cat_file = 'data/' + city + '/' + city + '_poi_cat.txt'

# 数据预处理
train_traj, train_time, train_cat, test_traj, test_time, test_cat, \
    history_traj, history_time, history_cat, voc_poi, train_user, test_user = data_process(
        train_file, test_file, time_train_file, time_test_file, cat_train_file, cat_test_file
    )

int_to_vocab, vocab_to_int = extract_words_vocab(voc_poi)

poi_num = len(int_to_vocab) + 1
poi_time_list = load_poi_time(poi_time_file, int_to_vocab)
poi_cat_list = load_poi_cat(poi_cat_file, int_to_vocab)

# 将原始数据进行预处理，并制作成data_set
train_data_set = MyDataset(data=train_traj, user=train_user, time=train_time, cat=train_cat,
                           del_label_flag=True, padding_idx=0, use_sos_eos=None)

test_data_set = MyDataset(data=test_traj, user=test_user, time=test_time, cat=test_cat,
                          del_label_flag=True, padding_idx=0, use_sos_eos=None)

train_data_iter = DataLoader(dataset=train_data_set, batch_size=batch_size, shuffle=True)
test_data_iter = DataLoader(dataset=test_data_set, batch_size=batch_size, shuffle=True)

# 导入数据嵌入层
node2vec_emb = torch.from_numpy(np.loadtxt('./embeddings/{}_node2vec_{}.txt'.format(city, emb_dim))).to(torch.float32)
# contra_emb = torch.from_numpy(np.array(pd.read_csv('./embeddings/{}_contrastive_{}.csv'.format(city, emb_dim//2)))).to(torch.float32)
# data_emb = torch.cat([node2vec_emb, contra_emb], dim=1)
data_emb = node2vec_emb

# 对时间和类别计算嵌入层
hetEmb = HetEmb(ct_dim=emb_dim, time_num=time_num, cat_num=cat_num)
zeros = torch.zeros([poi_num-1, 1])
poi_time = torch.tensor(poi_time_list).float()
poi_cat = torch.tensor(poi_cat_list).float()
poi_time = torch.cat([zeros, poi_time], dim=1)
poi_cat = torch.cat([zeros, poi_cat], dim=1)
pt_emb, pc_emb, time_emb, cat_emb = hetEmb(poi_time, poi_cat)

pos_encoding = positional_encoding(len(vocab_to_int), emb_dim // 2).to(device)

# 定义模型及其参数
model = ManModel(emb_dim=emb_dim, node_num=poi_num, hidden_dim=hidden_dim, z_dim=z_dim,
                 data_emb=data_emb, time_emb=time_emb, cat_emb=cat_emb, dist=dist).to(device)
# model.apply(weight_init)

# 读取预训练模型参数
if pre_train == 'None':
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, betas=(0.9, 0.99), eps=1e-08, weight_decay=0.001,
                                 amsgrad=True)
else:
    model_dict = model.state_dict()
    pretrained_dict = torch.load(
        './pretrains/{}_manifold_pretrain_checkpoint'.format(city) + '_' + str(emb_method) + '___' + str(dist) + '.pt'
    )
    pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}
    # 取出预训练模型中与新模型的dict中重合的部分
    model_dict.update(pretrained_dict)  # 用预训练模型参数更新new_model中的部分参数
    model.load_state_dict(model_dict)  # 将更新后的model_dict加载进new model中
    # 将预训练的参数冻结住
    freeze_param_list = pretrained_dict.keys()
    for name, param in model.named_parameters():
        if name in freeze_param_list:
            param.requires_grad = False

    # for name, param in model.named_parameters():
    #     print('name:', name)
    #     print('param:', param)

    # 被冻结的参数不参加训练
    optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=lr, betas=(0.9, 0.99),
                                 eps=1e-08, weight_decay=0.001, amsgrad=True)

scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.5)
stopper = EarlyStopping(
    patience=500,
    model_name='trains/{}_manifold_MODEL_checkpoint'.format(city) + '_' + str(emb_method) + str(emb_dim) + '_'
               + str(hidden_dim) + '_' + str(dist) + '_' + str(pre_train) + '.pt'
)


def train(model, pos_encoding, train_iters, test_iters, epochs=39):
    model_kwargs = {}
    model_kwargs.update({dist: dist})
    for epoch in range(epochs):
        model.train()
        epoch_loss = []
        Test_Acc_1 = 0
        Test_Acc_5 = 0
        Test_Acc_10 = 0
        Y = []
        Prob_Y = []
        for step, (traj, user, time, cat, label, length, mask) in enumerate(train_iters):
            # 将输入的数据放入GPU
            traj, time, cat, label, mask = traj.to(device), time.to(device), cat.to(device), \
                label.to(device), mask.to(device)

            # 处理历史数据，作为模型的输入
            his_traj, his_time, his_cat = read_batch_history(user)
            model_kwargs.update({'his_traj': his_traj})
            model_kwargs.update({'his_time': his_time})
            model_kwargs.update({'his_cat': his_cat})

            optimizer.zero_grad()
            predicted_sample, loss = model(x=traj, label=label, time=time, cat=cat, length=length, mask=mask,
                                           pos_encoding=pos_encoding, **model_kwargs)
            loss.backward()  # retain_graph=True
            epoch_loss.append(loss.item())
            optimizer.step()

            if step % 100 == 0:
                print('epoch', epoch + 1, 'step：', step, ', loss：', epoch_loss[-1])
        scheduler.step()

        if (epoch + 1) % 3 == 0:
            model.eval()
            with torch.no_grad():
                for step, (traj, user, time, cat, label, length, mask) in enumerate(test_iters):
                    # 将输入的数据放入GPU
                    traj, time, cat, label, mask = traj.to(device), time.to(device), cat.to(device), \
                        label.to(device), mask.to(device)

                    # 处理历史数据，作为模型的输入
                    his_traj, his_time, his_cat = read_batch_history(user)
                    model_kwargs.update({'his_traj': his_traj})
                    model_kwargs.update({'his_time': his_time})
                    model_kwargs.update({'his_cat': his_cat})

                    predicted_sample, _ = model(x=traj, label=label, user=user, time=time, cat=cat, length=length,
                                                mask=mask, pos_encoding=pos_encoding, **model_kwargs)

                    predicted_sample = predicted_sample.cpu().detach().numpy()
                    label = label.cpu().detach().numpy()
                    B = traj.size(0)
                    for i in range(B):
                        value = predicted_sample[i]
                        tag = label[i]
                        true_value = get_onehot(tag)
                        top1 = np.argpartition(a=-value, kth=1)[:1]
                        # print(top1,input_x[i][-1])
                        top5 = np.argpartition(a=-value, kth=5)[:5]
                        top10 = np.argpartition(a=-value, kth=10)[:10]
                        if top1[0] == tag:
                            Test_Acc_1 += 1
                        if tag in top5:
                            Test_Acc_5 += 1
                        if tag in top10:
                            Test_Acc_10 += 1
                        Y.append(true_value)
                        Prob_Y.append(value)

                ACC_1 = Test_Acc_1 / len(test_user)
                ACC_5 = Test_Acc_5 / len(test_user)
                ACC_10 = Test_Acc_10 / len(test_user)

                print('epoch', epoch + 1,
                      '\nTest accuracy@1：', ACC_1,
                      '\nTest accuracy@5：', ACC_5,
                      '\nTest accuracy@10：', ACC_10
                      )
                if stopper.step(Test_Acc_1, model):
                    break

                auc = 0
                map = 0
                Y = np.array(Y)
                Prob_Y = np.array(Prob_Y)
                auc = metric.roc_auc_score(Y.T, Prob_Y.T, average='micro')
                map = metric.average_precision_score(Y.T, Prob_Y.T, average='micro')
                print('---------------------------')
                print('AUC_value', auc)  # ,,average='micro'
                print('MAP_value', map)  # ,,average='micro'
                output(epoch + 1, ACC_1, ACC_5, ACC_10, auc, map)


def title():
    fw_res = open('./results/manifold_Result_{}.txt'.format(city), 'a')
    fw_res.flush()
    fw_res.write(
        '-----------this is title---------'
        '\n{}_manifold_MODEL'.format(city) + '_' + str(emb_method) + str(emb_dim) + '_' + str(hidden_dim) + '_'
        + str(dist) + '_' + str(pre_train) + '\n')
    fw_res.close()


def output(index, ACC_1, ACC_5, ACC_10, auc, map):
    fw_res = open('./results/manifold_Result_{}.txt'.format(city), 'a')
    fw_res.flush()
    fw_res.write(
        'epoch' + str(index) +
        '\tACC@1:\t{:.4f}'.format(ACC_1) + '\tACC@5:\t{:.4f}'.format(ACC_5) + '\tACC@10:\t{:.4f}'.format(ACC_10) +
        '\tAUC:\t{:.4f}'.format(auc) + '\tMAP:\t{:.4f}'.format(map) + '\n')
    fw_res.close()


if __name__ == '__main__':
    title()
    # model = torch.compile(model)
    train(model=model, pos_encoding=pos_encoding, train_iters=train_data_iter, test_iters=test_data_iter)
