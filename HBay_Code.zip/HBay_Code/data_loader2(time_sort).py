import numpy as np
import torch
import pandas as pd
from torch.utils.data import TensorDataset


# from umap import UMAP


# 定义自己的Dataset类
class MyDataset(TensorDataset):
    def __init__(self, data, user, time, cat, voc_poi, padding_idx, use_sos_eos, del_label_flag=False):
        super(TensorDataset, self).__init__()
        # 读取数据文件
        self.data = data
        self.user = user
        self.time = time
        self.cat = cat
        self.voc_poi = voc_poi

        self.label_flag = del_label_flag
        self.padding_idx = padding_idx
        self.sos_eos = use_sos_eos
        self.poi_num = 0

        int_to_vocab, vocab_to_int = self.extract_words_vocab(voc_poi)

        data = self.convert_data(data, vocab_to_int)
        # user = list(map(int, user))
        time = self.convert_het_data(time)
        cat = self.convert_het_data(cat)

        # 对数据按照时间进行排序
        index_list = []
        for i in range(len(time)):
            index = np.argsort(time[i])
            data[i] = data[i][index]
            time[i] = time[i][index]
            cat[i] = cat[i][index]
            index_list.append(index)

        # 获取数据的标签
        label = self.get_label(data)

        # 填充数据与起止符设置
        max_poiid = max(max(row) for row in data)
        sos = [max_poiid + 1]
        eos = [max_poiid + 2]
        pad = self.padding_idx
        # 对数据进行填充

        data_list, lengths_list = self.pad_sentence_batch(data, pad)
        time_list, _ = self.pad_sentence_batch(time, pad)
        cat_list, _ = self.pad_sentence_batch(cat, pad)

        self.poi_num = max_poiid + 1
        # 数据添加起止符
        if self.sos_eos:
            data_list = self.add_sos_eos(data_list, sos, eos)
            self.poi_num = self.poi_num + 2

        data = torch.tensor(data_list)
        time = torch.tensor(time_list)
        cat = torch.tensor(cat_list)
        lengths = torch.tensor(lengths_list)
        mask = data.clone().detach().gt(0)

        if self.label_flag:
            # 删除数据的标签
            data = self.del_label(data, lengths)
            time = self.del_label(time, lengths)
            cat = self.del_label(cat, lengths)
            mask = data.clone().detach().gt(0)
            lengths = torch.count_nonzero(data, dim=1)
            # man_data = man_data[:, :-1, :]
            # man_mask = torch.broadcast_to(mask.unsqueeze(-1), man_data.shape)
            # man_data = man_data * man_mask
        # 将数据进行转换
        self.data = data
        self.time = time
        self.cat = cat
        # self.man_data = man_data
        self.label = torch.tensor(label)
        self.lengths = lengths
        self.mask = mask

        # print(man_dim)

    def __len__(self):
        # 返回数据集的大小
        return len(self.data)

    def __getitem__(self, index):
        return \
            self.data[index], self.user[index], self.time[index], self.cat[index], \
                self.label[index], self.lengths[index], self.mask[index]

    def get_poi_num(self):
        return self.poi_num

    def extract_words_vocab(self, voc_poi):
        int_to_vocab = {idx + 1: word for idx, word in enumerate(voc_poi)}
        vocab_to_int = {word: idx for idx, word in int_to_vocab.items()}
        return int_to_vocab, vocab_to_int

    def convert_data(self, DATA, vocab_to_int):
        new_DATA = list()
        for i in range(len(DATA)):  # TRAIN
            temp = list()
            for j in range(len(DATA[i])):
                temp.append(vocab_to_int[DATA[i][j]])
            temp = np.array(temp)
            new_DATA.append(temp)
        return new_DATA

    def create_trajectories(self, data, voc_poi):
        int_to_vocab, vocab_to_int = self.extract_words_vocab(voc_poi)
        trajectories = self.convert_data(data, vocab_to_int)
        return trajectories

    def pad_sentence_batch(self, sentence_batch, pad_idx):
        max_sentence = max([len(sentence) for sentence in sentence_batch])  # 取最大长度
        lengths_list = [len(sentence) for sentence in sentence_batch]
        return [np.pad(sentence, (0, max_sentence - len(sentence))) for sentence in sentence_batch], lengths_list
        # return [sentence + [pad_idx] * (max_sentence - len(sentence)) for sentence in sentence_batch], lengths_list

    def add_sos_eos(self, trajectoreis, sos, eos):
        # 添加开始符号和终止符号
        for i in range(len(trajectoreis)):
            trajectoreis[i] = sos + trajectoreis[i] + eos
        return trajectoreis

    def get_label(self, trajectoreis):
        label = []
        for i in range(len(trajectoreis)):
            label.append(trajectoreis[i][-1])
        return label

    def del_tensor_ele(self, tensor, index):
        tensor1 = tensor[:index]
        tensor2 = tensor[index + 1:]
        return torch.cat([tensor1, tensor2], dim=0)

    def del_label(self, trajs, lengths):  # 去掉轨迹的最后一个poi
        nolabel_trajectorties = []
        for i, traj in enumerate(trajs):
            nolabel_trajectorties.append(self.del_tensor_ele(traj, lengths[i] - 1).unsqueeze(0))
        return torch.cat(nolabel_trajectorties, dim=0)

    def convert_het_data(self, DATA):
        new_DATA = list()
        for i in range(len(DATA)):  # TRAIN
            temp = list()
            for j in range(len(DATA[i])):
                temp.append(int(DATA[i][j]) + 1)
            temp = np.array(temp)
            new_DATA.append(temp)
        return new_DATA
